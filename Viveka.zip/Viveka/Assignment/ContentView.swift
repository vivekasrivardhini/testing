import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color(#colorLiteral(red: 0.11, green: 0.05, blue: 0.34, alpha: 1.0)),Color(#colorLiteral(red: 0.3647058904, green: 0.06666667014, blue: 0.9686274529, alpha: 1))]),
                           startPoint: .top,
                           endPoint: .bottom)

            VStack(spacing: 24) {
                HStack{
                    
                        Image(systemName: "person.circle.fill")
                            .resizable()
                            .frame(width: 100, height: 100)
                            .foregroundColor(.blue.opacity(0.9))
                        VStack(alignment: .leading) {
                            Text("Viveka SriVardhini")
                                .font(.title)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                            
                            Text("Age 18")
                                .font(.subheadline)
                                .foregroundColor(.white.opacity(0.7))
                        }
                }

                VStack(alignment: .leading, spacing: 4) {
                    Text("Bio")
                        .font(.headline)
                        .foregroundColor(.white)

                    Text("iOS Developer, coffee enthusiast, and part-time bug fixer.")
                        .font(.subheadline)
                        .foregroundColor(.white.opacity(0.7))
                        .multilineTextAlignment(.leading)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal)

                VStack(alignment: .leading, spacing: 8) {
                    Text("Gallery")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(.horizontal)

        
                    VStack(spacing: 12) {
                        ForEach(0..<4) { _ in
                            HStack(spacing: 12) {
                                ForEach(0..<3) { _ in
                                    RoundedRectangle(cornerRadius: 12)
                                        .fill(Color.white.opacity(0.1))
                                        .frame(width: 100, height: 100)
                                        .overlay(
                                            Image(systemName: "photo")
                                                .resizable()
                                                .scaledToFit()
                                                .frame(width: 40, height: 40)
                                                .foregroundColor(.white.opacity(0.6))
                                        )
                                }
                            }
                        }
                    }
                }

                Spacer()
            }
            .padding(.top, 60)
        }
    }
}

#Preview {
    ContentView()
}

